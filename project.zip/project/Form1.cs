﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;       
using System.Net.Sockets;
using System.Threading;

namespace server
{
    public partial class Form1 : Form
    {

        Socket listen_socket;
        Socket client_socket;   
        bool isConnected;  

        byte[] bytes = new byte[1024];
        string data;  
        public Form1()
        {
            InitializeComponent();
            isConnected = false;   
        }

        private void button1_Click(object sender, EventArgs e)
        {
            start("127.0.0.1", 3434, 10);   //테스트용 로컬 주소                          
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        public void start(string host, int port, int backlog)
        {
            this.listen_socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            IPAddress address;
            if (host == "0.0.0.0")
            {
                address = IPAddress.Any;
            }
            else
            {
                address = IPAddress.Parse(host);
            }
            IPEndPoint endpoint = new IPEndPoint(address, port);

            try
            {
                listen_socket.Bind(endpoint);
                listen_socket.Listen(backlog);

                client_socket = listen_socket.Accept();
                listBox1.Items.Add("고객님과의 연결");
                isConnected = true;
                Thread listen_thread = new Thread(do_receive);
                listen_thread.Start();
            }
            catch (Exception e)
            {

            }
        }
        void do_receive()
        {
            while (isConnected)
            {
                while (true)
                {
                    byte[] bytes = new byte[1024];
                    int bytesRec = client_socket.Receive(bytes);
                    data += Encoding.UTF8.GetString(bytes, 0, bytesRec);
                    if (data.IndexOf("<eof>") > -1)
                        break;
                }
                data = data.Substring(0, data.Length - 5);
                Invoke((MethodInvoker)delegate
                {
                    listBox1.Items.Add(data);
                }
                );
                data = "";
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (isConnected == false)
                return;
            byte[] msg = Encoding.UTF8.GetBytes(String.Format("상담원 : {0}", textBox1.Text) + "<eof>");
            int bytesSent = client_socket.Send(msg);
            listBox1.Items.Add(String.Format("상담원 : {0}", textBox1.Text));
            textBox1.Clear();
            textBox1.Text = "";
        }
    }
}


