﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace Client
{
    public partial class Form1 : Form
    {
        Socket client_socket;
        bool isConnected;
        byte[] bytes = new byte[1024];
        string data;

        public Form1()
        {
            InitializeComponent();
            isConnected = false;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (isConnected == false)
                return;
            byte[] msg = Encoding.UTF8.GetBytes(String.Format("회원님 : {0}", textBox2.Text) + "<eof>");
            int bytesSent = client_socket.Send(msg);
            listBox1.Items.Add(String.Format("회원님 : {0}", textBox2.Text));
            textBox2.Clear();
            textBox2.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        { 
            if (isConnected == true)
                return;
            client_socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            client_socket.Connect(new IPEndPoint(IPAddress.Parse(textBox1.Text), 3434));
            listBox1.Items.Add("상담원과의 연결이 시작되었습니다!");
            isConnected = true;
            Thread listen_thread = new Thread(do_receive);
            listen_thread.Start();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        void do_receive()
        {
            while (isConnected)
            {
                while (true)
                {
                    byte[] bytes = new byte[1024];
                    int bytesRec = client_socket.Receive(bytes);
                    data += Encoding.UTF8.GetString(bytes, 0, bytesRec);
                    if (data.IndexOf("<eof>") > -1)
                        break;
                }
                data = data.Substring(0, data.Length - 5);
                Invoke((MethodInvoker)delegate
                {
                    listBox1.Items.Add(data);
                }
                );
                data = "";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (isConnected == false)
                return;
            byte[] msg = Encoding.UTF8.GetBytes("회원님 : 환불을 요청합니다" + "<eof>");
            int bytesSent = client_socket.Send(msg);
            listBox1.Items.Add(String.Format("회원님 : 환불을 요청합니다"));
            textBox2.Clear();
            textBox2.Text = "";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (isConnected == false)
                return;
            byte[] msg = Encoding.UTF8.GetBytes("회원님 : 반품을 요청합니다" + "<eof>");
            int bytesSent = client_socket.Send(msg);
            listBox1.Items.Add(String.Format("회원님 : 반품을 요청합니다"));
            textBox2.Clear();
            textBox2.Text = "";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (isConnected == false)
                return;
            byte[] msg = Encoding.UTF8.GetBytes("회원님 : 제품에 대해 더 자세히 알 수 있을까요?" + "<eof>");
            int bytesSent = client_socket.Send(msg);
            listBox1.Items.Add(String.Format("회원님 : 제품에 대해 더 자세히 알 수 있을까요?"));
            textBox2.Clear();
            textBox2.Text = "";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (isConnected == false)
                return;
            byte[] msg = Encoding.UTF8.GetBytes("회원님 : 배송이 얼마나 되는지 알 수 있을까요?" + "<eof>");
            int bytesSent = client_socket.Send(msg);
            listBox1.Items.Add(String.Format("회원님 : 배송이 얼마나 되는지 알 수 있을까요?"));
            textBox2.Clear();
            textBox2.Text = "";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}